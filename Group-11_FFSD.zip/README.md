# FSD1

Install the dependencies using 
```
npm ci
```

then run ```npm start``` command.


PROJECT URL:

```
https://github.com/MohitAswani/StudentHUB
```
